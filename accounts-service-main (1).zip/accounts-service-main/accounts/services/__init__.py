"""Services package initialization"""
